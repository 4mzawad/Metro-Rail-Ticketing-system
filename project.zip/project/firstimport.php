<?php
$host="localhost"; 
$username="root";
$password=""; 
$db_name="traindb"; 

$conn=mysqli_connect("$host", "$username", "$password")or die("cannot connect");

?>